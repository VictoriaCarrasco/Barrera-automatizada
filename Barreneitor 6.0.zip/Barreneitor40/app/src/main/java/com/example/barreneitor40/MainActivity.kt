package com.example.barreneitor40

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Mantienes tu configuración original
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // ==============================
        // RECIBIR DATOS DEL LOGIN
        // ==============================
        val rol = intent.getStringExtra("ROL") ?: "usuario"
        val nombre = intent.getStringExtra("NOMBRE") ?: "desconocido"

        // ==============================
        // REFERENCIA A UN TEXTVIEW (puedes usar el que ya tienes)
        // ==============================
        val txtInfo = findViewById<TextView>(R.id.txtInfo) // <-- debe existir en tu layout

        // ==============================
        // MOSTRAR MENSAJE SEGÚN EL ROL
        // ==============================
        if (rol == "admin") {
            txtInfo.text = "Bienvenido ADMIN: $nombre"
        } else {
            txtInfo.text = "Sesión iniciada como Usuario: $nombre"
        }

        // ==============================
        // EJEMPLO DE RESTRICCIÓN POR ROL
        // (comenta esto si no tienes botones aún)
        // ==============================
        /*
        val btnLedOn = findViewById<Button>(R.id.btnLedOn)
        val btnLedOff = findViewById<Button>(R.id.btnLedOff)

        if (rol == "usuario") {
            btnLedOn.isEnabled = false
            btnLedOff.isEnabled = false
        }
        */
    }
}
