package com.example.barreneitor40

data class User(
    val username: String,
    val password: String,
    val role: Role
)
