package com.example.barreneitor40

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import kotlin.concurrent.thread

class ParkingActivity : AppCompatActivity() {

    private lateinit var txtObstacle: TextView
    private lateinit var txtBarrier: TextView
    private lateinit var txtFecha: TextView
    private lateinit var btnUp: Button
    private lateinit var btnDown: Button

    private lateinit var edtArduinoIp: EditText
    private lateinit var btnConnect: Button
    private lateinit var txtConnectionStatus: TextView

    // ⭐ NUEVO BOTÓN ⭐
    private lateinit var btnBack: Button

    // Android escucha aquí (Arduino envía estado)
    private val puertoEscucha = 4210

    // Android envía comandos aquí (Arduino escucha)
    private val puertoEnvio = 4211

    // IP por defecto (puedes cambiarla o escribirla en la app)
    private var ipArduino: String = "192.168.1.100"

    @Volatile
    private var escuchando = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_parking)

        // Referencias UI
        txtObstacle = findViewById(R.id.txtObstacle)
        txtBarrier = findViewById(R.id.txtBarrier)
        txtFecha = findViewById(R.id.txtFecha)
        btnUp = findViewById(R.id.btnUp)
        btnDown = findViewById(R.id.btnDown)

        edtArduinoIp = findViewById(R.id.edtArduinoIp)
        btnConnect = findViewById(R.id.btnConnect)
        txtConnectionStatus = findViewById(R.id.txtConnectionStatus)

        // ⭐ REFERENCIA DEL BOTÓN VOLVER ⭐
        btnBack = findViewById(R.id.btnBack)

        // ⭐ ACCIÓN DEL BOTÓN VOLVER ⭐
        btnBack.setOnClickListener {
            escuchando = false
            finish() // vuelve sin cerrar la app
        }

        // Mostrar IP por defecto en el campo de texto
        edtArduinoIp.setText(ipArduino)

        // Botón CONECTAR
        btnConnect.setOnClickListener {
            val ipIngresada = edtArduinoIp.text.toString().trim()
            if (ipIngresada.isNotEmpty()) {
                ipArduino = ipIngresada
            }

            if (!escuchando) {
                escuchando = true
                iniciarRecepcionUDP()
                runOnUiThread {
                    txtConnectionStatus.text = "Estado: Conectando..."
                }
                Toast.makeText(
                    this,
                    "Intentando conectar con $ipArduino",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    this,
                    "Ya se está escuchando al Arduino",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        // Botones SUBIR / BAJAR barrera
        btnUp.setOnClickListener { enviarComando("UP") }
        btnDown.setOnClickListener { enviarComando("DOWN") }
    }

    override fun onDestroy() {
        super.onDestroy()
        escuchando = false
    }

    private fun iniciarRecepcionUDP() {
        thread {
            try {
                val socket = DatagramSocket(puertoEscucha)
                val buffer = ByteArray(1024)

                runOnUiThread {
                    txtConnectionStatus.text = "Estado: Esperando datos..."
                }

                while (escuchando) {
                    val paquete = DatagramPacket(buffer, buffer.size)
                    socket.receive(paquete)

                    val mensaje = String(paquete.data, 0, paquete.length)
                    procesarMensaje(mensaje)
                }

                socket.close()
            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    txtConnectionStatus.text = "Estado: Error de conexión"
                    Toast.makeText(
                        this,
                        "Error en la recepción UDP",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    private fun procesarMensaje(mensaje: String) {
        var obstacleStr = "--"
        var barrierStr = "--"
        var fechaStr = "--"

        val partes = mensaje.split(";")
        for (p in partes) {
            val kv = p.split("=")
            if (kv.size == 2) {
                when (kv[0]) {
                    "OBSTACLE" -> obstacleStr = if (kv[1] == "1") "SÍ" else "NO"
                    "BARRIER" -> barrierStr = kv[1]
                    "DATE" -> fechaStr = kv[1]
                }
            }
        }

        runOnUiThread {
            txtObstacle.text = "Obstáculo: $obstacleStr"
            txtBarrier.text = "Barrera: $barrierStr"
            txtFecha.text = "Fecha: $fechaStr"

            txtConnectionStatus.text = "Estado: Conectado"

            if (obstacleStr == "SÍ") {
                Toast.makeText(this, "¡Obstáculo detectado!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun enviarComando(comando: String) {
        thread {
            try {
                val socket = DatagramSocket()
                val data = comando.toByteArray()
                val ip = InetAddress.getByName(ipArduino)

                val paquete = DatagramPacket(data, data.size, ip, puertoEnvio)
                socket.send(paquete)
                socket.close()
            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "Error enviando comando $comando",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
}



