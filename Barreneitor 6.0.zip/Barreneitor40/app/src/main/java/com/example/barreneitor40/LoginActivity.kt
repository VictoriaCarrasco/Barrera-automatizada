package com.example.barreneitor40

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var edtUsername: EditText
    private lateinit var edtPassword: EditText
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        edtUsername = findViewById(R.id.edtUsername)
        edtPassword = findViewById(R.id.edtPassword)
        btnLogin = findViewById(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val username = edtUsername.text.toString().trim()
            val password = edtPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Completa usuario y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // -------------------------
            // VALIDACIÓN DE USUARIOS
            // -------------------------
            val role = when {
                username == "doki" && password == "1234" -> "admin"
                username == "user" && password == "1234" -> "usuario"
                else -> null
            }

            if (role == null) {
                Toast.makeText(this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Toast.makeText(this, "Bienvenido $username", Toast.LENGTH_SHORT).show()

            // -------------------------
            // REDIRECCIÓN SEGÚN ROL
            // -------------------------
            val intent = when (role) {
                "admin" -> Intent(this, AdminActivity::class.java)
                "usuario" -> Intent(this, ParkingActivity::class.java)
                else -> Intent(this, MainActivity::class.java) // por seguridad
            }

            intent.putExtra("ROL", role)
            intent.putExtra("NOMBRE", username)
            startActivity(intent)
            finish()
        }
    }
}
