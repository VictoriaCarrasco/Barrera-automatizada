package com.example.barreneitor40

enum class Role {
    ADMIN,
    NORMAL
}