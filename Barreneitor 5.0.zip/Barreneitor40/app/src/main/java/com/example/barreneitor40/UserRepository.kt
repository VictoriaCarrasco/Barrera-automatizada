package com.example.barreneitor40

object UserRepository {

    // Usuarios de prueba iniciales
    private val users = mutableListOf(
        User("admin", "admin123", Role.ADMIN),
        User("user1", "1234", Role.NORMAL)
    )

    fun getAllUsers(): List<User> = users.toList()

    fun authenticate(username: String, password: String): User? {
        return users.find { it.username == username && it.password == password }
    }

    fun addUser(username: String, password: String, role: Role): Boolean {
        // No permitir duplicados
        if (users.any { it.username == username }) {
            return false
        }
        users.add(User(username, password, role))
        return true
    }

    fun deleteUser(username: String): Boolean {
        val user = users.find { it.username == username }
        return if (user != null) {
            users.remove(user)
            true
        } else {
            false
        }
    }
}
