package com.example.barreneitor40

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AdminActivity : AppCompatActivity() {

    private lateinit var listUsers: ListView
    private lateinit var edtNewUser: EditText
    private lateinit var edtNewPassword: EditText
    private lateinit var spinnerRole: Spinner
    private lateinit var btnCreateUser: Button
    private lateinit var edtDeleteUser: EditText
    private lateinit var btnDeleteUser: Button

    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin)

        listUsers = findViewById(R.id.listUsers)
        edtNewUser = findViewById(R.id.edtNewUser)
        edtNewPassword = findViewById(R.id.edtNewPassword)
        spinnerRole = findViewById(R.id.spinnerRole)
        btnCreateUser = findViewById(R.id.btnCreateUser)
        edtDeleteUser = findViewById(R.id.edtDeleteUser)
        btnDeleteUser = findViewById(R.id.btnDeleteUser)

        // Spinner de roles
        val roles = listOf("ADMIN", "NORMAL")
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, roles)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerRole.adapter = spinnerAdapter

        // Lista de usuarios
        adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            UserRepository.getAllUsers().map { "${it.username} (${it.role})" }
        )
        listUsers.adapter = adapter

        // Botón crear usuario
        btnCreateUser.setOnClickListener {
            val username = edtNewUser.text.toString().trim()
            val password = edtNewPassword.text.toString().trim()
            val roleStr = spinnerRole.selectedItem.toString()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Completa usuario y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val role = if (roleStr == "ADMIN") Role.ADMIN else Role.NORMAL

            val creado = UserRepository.addUser(username, password, role)
            if (!creado) {
                Toast.makeText(this, "El usuario ya existe", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Usuario creado", Toast.LENGTH_SHORT).show()
                actualizarLista()
                edtNewUser.text.clear()
                edtNewPassword.text.clear()
            }
        }

        // Botón eliminar usuario
        btnDeleteUser.setOnClickListener {
            val username = edtDeleteUser.text.toString().trim()
            if (username.isEmpty()) {
                Toast.makeText(this, "Ingresa el usuario a eliminar", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val eliminado = UserRepository.deleteUser(username)
            if (eliminado) {
                Toast.makeText(this, "Usuario eliminado", Toast.LENGTH_SHORT).show()
                actualizarLista()
                edtDeleteUser.text.clear()
            } else {
                Toast.makeText(this, "Usuario no encontrado", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun actualizarLista() {
        adapter.clear()
        adapter.addAll(
            UserRepository.getAllUsers().map { "${it.username} (${it.role})" }
        )
        adapter.notifyDataSetChanged()
    }
}
